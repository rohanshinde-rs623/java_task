/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc1;

import static com.mysql.cj.Messages.getString;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import static javax.swing.UIManager.getInt;
import static jdk.nashorn.internal.objects.NativeDate.getDate;

/**
 *
 * @author Rohan shinde
 */
public class Oprations {
     public static void main(String[] args) throws SQLException, ClassNotFoundException {
       
          try{

      Class.forName("com.mysql.cj.jdbc.Driver");
       Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3307/test1","root", "");
          
       
       
       Statement st=con.createStatement();
       
       
       
       
       ResultSet rs;
       int student_no,student_dob,student_doj,choice,a;
       String student_name;
       Scanner sc=new Scanner(System.in);
         
       while(true)
       {
           System.out.println("\n \n Enter the choice");
           System.out.println("no 1 Insert data");
           System.out.println("no 2 update data");
           System.out.println("no 3 Delete data");
           System.out.println("no 4 select all data a data");
           System.out.println("no 5 one student by id filter.");
           System.out.println("no 6 close defult");
           
	   choice=sc.nextInt();
           	   switch(choice)
          {
              case 1: //insert
                    int i=st.executeUpdate( "INSERT INTO student1 VALUES (1,'roahn shinde','2000-06-27','2011-11-11')");
                           if(i>0)
				System.out.println("Insertion done.");
			   else
				System.out.println("Insertion not done.");
			   break;
                                        
                                        
              case 2: //update
		         i=st.executeUpdate("update Student1 set student_doj = '2012-12-10'  where  student_no = '1' ;");
			     if(i>0)
				System.out.println("Updation done.");
			     else
				System.out.println("Updation not done.");
			     break;                          
                                    
              case 3: //delete
                         i=st.executeUpdate("delete from Student1 where student_name = 'roahn shinde';");
                             if(i>0)
                                System.out.println("delete done.");
                              else
                                System.out.println("delete not done.");
                             break; 
                             
              case 4://select
	                 rs=st.executeQuery("select * from Student1;");
			      while(rs.next())
				{
			        	System.out.println(rs.getInt("student_no")+"  "+rs.getString("student_name")+"  "+rs.getDate("student_dob")+" "+rs.getDate("student_doj") );
				}
				break;	
              case 5: //one student by id filter.  
                  
                    System.out.print("Enter student id want to search");  
                       a= sc.nextInt(); 
                       
                       String q3 =  "SELECT *  FROM Student1 WHERE student_no ='"+ a +"'" ;
                        rs = st.executeQuery(q3);	
                        if(rs.next())	
                            {
                            System.out.println(rs.getInt("student_no")+"  "+rs.getString("student_name")+"  "+rs.getDate("student_dob")+" "+rs.getDate("student_doj") );
                            }
                        else{ System.out.print("Enter id wrong\n " ); 
                        
                        }
                         break;
                         
              case 6:con.close();
		 System.exit(1);
                 break;
           }
      }
       
       
   
  }  
  
  
  
 }
    
}
